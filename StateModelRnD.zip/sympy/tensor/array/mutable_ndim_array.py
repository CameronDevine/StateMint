from sympy.tensor.array.ndim_array import NDimArray


class MutableNDimArray(NDimArray):

    pass
